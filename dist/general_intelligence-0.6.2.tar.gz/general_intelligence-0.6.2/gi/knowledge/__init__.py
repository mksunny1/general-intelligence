from gi.knowledge.functions import FunctionKnowledge
