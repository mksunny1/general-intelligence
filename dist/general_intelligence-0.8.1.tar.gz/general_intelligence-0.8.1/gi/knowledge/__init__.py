from gi.knowledge.functions import FunctionKnowledge, make_combinations, make_permutations, on, Context
