from .core import GeneralIntelligence, Knowledge, difference

__version__ = "0.1.0"
